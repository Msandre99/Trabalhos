document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registrationForm');
    const completeButton = document.getElementById('completeButton');
    const profilePhotoInput = document.getElementById('profilePhoto');
    const photoPreview = document.getElementById('photo-preview');

    // Photo preview functionality
    profilePhotoInput.addEventListener('change', function (event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                photoPreview.src = e.target.result;
                photoPreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            photoPreview.src = '#';
            photoPreview.style.display = 'none';
        }
    });

    completeButton.addEventListener('click', async (event) => {
        event.preventDefault(); // Prevent default form submission

        // Basic form validation (you can expand this)
        const inputs = registrationForm.querySelectorAll('input[required]');
        let allFieldsFilled = true;
        inputs.forEach(input => {
            if (!input.value.trim()) {
                allFieldsFilled = false;
                input.style.borderColor = 'red'; // Highlight empty fields
            } else {
                input.style.borderColor = ''; // Reset border color
            }
        });

        if (!allFieldsFilled) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        // Gather form data
        const formData = {
            fullName: document.getElementById('fullName').value,
            dob: document.getElementById('dob').value,
            email: document.getElementById('email').value,
            phoneNumber: document.getElementById('phoneNumber').value,
            gender: document.getElementById('gender').value,
            // address: document.getElementById('address').value,
            // idType: document.getElementById('idType').value,
            cpf: document.getElementById('cpf').value,
            issueAuthority: document.getElementById('issueAuthority').value,
            issueState: document.getElementById('issueState').value,
            // issueDate: document.getElementById('issueDate').value,
            // expiryDate: document.getElementById('expiryDate').value,
            fullAddress: document.getElementById('fullAddress').value,
            nationality: document.getElementById('nationality').value,
            state: document.getElementById('state').value,
            neighborhood: document.getElementById('neighborhood').value,
            houseNumber: document.getElementById('houseNumber').value,
            profilePhoto: photoPreview.src !== '#' ? photoPreview.src : null // Get base64 image or null
        };

        // --- Generate PDF ---
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        let y = 20; // Initial Y position for text

        // Title
        doc.setFontSize(22);
        doc.text("Comprovante de Filiação", 105, y, null, null, "center");
        y += 15;

        // Add photo if available
        if (formData.profilePhoto && formData.profilePhoto !== 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=') { // Check for actual image data, not just empty data URI
            try {
                // Image dimensions and position
                const imgWidth = 50;
                const imgHeight = 50;
                doc.addImage(formData.profilePhoto, 'JPEG', 150, y, imgWidth, imgHeight);
                y += imgHeight + 10; // Adjust y position after image
            } catch (error) {
                console.error("Error adding image to PDF:", error);
                doc.text("Erro ao carregar foto", 150, y);
                y += 10;
            }
        }


        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text("Informações Pessoais:", 20, y);
        y += 10;
        doc.setFont('helvetica', 'normal');
        doc.text(`Nome Completo: ${formData.fullName}`, 20, y); y += 7;
        doc.text(`Data de Nascimento: ${formData.dob}`, 20, y); y += 7;
        doc.text(`CPF: ${formData.cpf}`, 20, y); y += 7;
        doc.text(`Email: ${formData.email}`, 20, y); y += 7;
        doc.text(`Número de Celular: ${formData.phoneNumber}`, 20, y); y += 7;
        doc.text(`Gênero: ${formData.gender}`, 20, y); y += 15;
        // doc.text(`Endereço: ${formData.address}`, 20, y); y += 15;

        doc.setFont('helvetica', 'bold');
        doc.text("Informações de Endereço:", 20, y);
        y += 10;
        doc.setFont('helvetica', 'normal');
        // doc.text(`Tipo de ID: ${formData.idType}`, 20, y); y += 7;
        doc.text(`Estado: ${formData.issueState}`, 20, y); y += 7;
        doc.text(`Cidade: ${formData.issueAuthority}`, 20, y); y += 7;
        doc.text(`Bairro: ${formData.neighborhood}`, 20, y); y += 7;
        doc.text(`Endereço Completo: ${formData.fullAddress}`, 20, y); y += 7;
        doc.text(`Número da Casa: ${formData.houseNumber}`, 20, y); y += 15;
        // doc.text(`Data de Emissão: ${formData.issueDate}`, 20, y); y += 7;
        // doc.text(`Data de Validade: ${formData.expiryDate}`, 20, y); y += 15;

        doc.setFont('helvetica', 'bold');
        doc.text("Informações do Plano:", 20, y);
        y += 10;
        doc.setFont('helvetica', 'normal');

        doc.text(`Plano: ${formData.nationality}`, 20, y); y += 7;
        doc.text(`Periodo: ${formData.state}`, 20, y); y += 7;


        // Footer
        doc.setFontSize(10);
        doc.text("Documento gerado automaticamente. As informações aqui contidas são para comprovação de filiação.", 105, doc.internal.pageSize.height - 10, null, null, "center");

        // Save the PDF
        doc.save(`${formData.fullName.replace(/\s/g, '_')}_comprovante_filiacao.pdf`);
    });
});
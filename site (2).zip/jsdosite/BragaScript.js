
    let toogleBnt = document.querySelector('.area_btn');
    let proPrice = document.querySelector('#diamond');
    let premiumPrice = document.querySelector('#gold');
    let lowerPrice = document.querySelector('#basic');

    toogleBnt.addEventListener('click', () => {
        const newLower = lowerPrice.innerHTML === '29,90' ? '349,90' : '29,90';
        lowerPrice.innerHTML = newLower;
        const newPremium = premiumPrice.innerHTML === '79,90' ? '949,90' : '79,90';
        premiumPrice.innerHTML = newPremium;
        const newPro = proPrice.innerHTML === '159,90' ? '1889,90' : '159,90';
        proPrice.innerHTML = newPro;
    })


